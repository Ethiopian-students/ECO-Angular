export class Appointment
{
    public userID?:any;
    public uname:string;
    public fname:string;
    public lname:string;
    public pwd:string;

    constructor(uname:string,fname:string,lname:string,pwd:string,userID?:any)
    {
        this.userID = userID;
        this.uname = uname;
        this.fname = fname;
        this.lname = lname;
        this.pwd = pwd;
    }

    login()
    {}

    logout()
    {}

    register()
    {

    }

} 