export class Application
{
    public applicationID?:any;
    public applicationType:string;

    constructor(applicationType:string,applicationID?:any)
    {
        this.applicationID = applicationID;
        this.applicationType = applicationType;
    }

    getPassportApplications()
    {

    }

    getVisaApplication()
    {

    }

    getPowerOfAttorney()
    {}
}