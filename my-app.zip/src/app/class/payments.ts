export class Payment
{
    public paymentID?:any;
    public paymentAccount:any;
    public userID:any;
    constructor(paymentAccount:any,userID:any,paymentID?:any)
    {
        this.paymentAccount = paymentAccount;
        this.paymentID = paymentID;
        this.userID = userID;
    }

    getPayment()
    {

    }

    generateInvoice()
    {

    }

    generateReceipts()
    {}
}