export class Passports
{
    public passportID?:any;
    public userID:any;
    public dateofApplication:Date;

    constructor(userID:any,dateofApplication:Date,passportID?:any)
    {
        this.userID = userID;
        this.dateofApplication = dateofApplication;
        this.passportID = passportID;
    }

    createApplication()
    {

    }

    editApplication()
    {

    }

    closeApplication()
    {
        
    }
}