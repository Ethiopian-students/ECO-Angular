import { Component, OnInit, Input } from '@angular/core';
import { QuestionControlService } from '../question-control.service';
import { QuestionBase } from '../question-base';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.css'],
  providers: [ QuestionControlService ]
})
export class DynamicFormComponent implements OnInit {

  @Input() questions: QuestionBase<any>[] = [];
  form: FormGroup;
  payLoad = '';
  
  constructor(private qcs: QuestionControlService,private fb: FormBuilder) { }

  ngOnInit() {
    // this.form = this.qcs.toFormGroup(this.questions);
    this.form =this.fb.group(this.qcs.toFormGroup(this.questions))
  }

  onSubmit() {
    this.payLoad = JSON.stringify(this.form.value);
  }
  
}
