import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  auths={username:'',pass:''};
  constructor(private router:Router) { }

  ngOnInit() {
  }

  onSubmit()
  {
    console.log("Auth : ",this.auths)
    if(this.auths.username == 'nishantraj656@gmail.com' && this.auths.pass == 'sushil123kumar')
    {
      localStorage.setItem('Token',"Test");
      this.router.navigateByUrl('register');
    }
  }
}
