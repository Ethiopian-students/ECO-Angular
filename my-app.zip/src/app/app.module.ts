import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule, appRoutingComponent } from './app-routing.module';
import { AppComponent } from './app.component';

import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { DynamicFormComponent } from './dynamic-form/dynamic-form.component';
import { DynamicFormQuestionComponent } from './dynamic-form-question/dynamic-form-question.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { LayoutComponent } from './shared/layout/layout.component'; // <-- NgModel lives here
import { UserSystemModule } from './shared/user-system.module';


@NgModule({
  declarations: [
    AppComponent,
    DynamicFormComponent,
    DynamicFormQuestionComponent,
    appRoutingComponent
  ],
  imports: [
    BrowserModule,
   
    FormsModule,
    ReactiveFormsModule,
    UserSystemModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent],
 
})
export class AppModule { }
