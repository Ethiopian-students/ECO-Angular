import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.css']
})
export class OrderListComponent implements OnInit {

  orderList=[{name:'Joy',status:'done',date:'12-12-2018'},{name:'Roy',status:'cancel',date:'12-10-2018'},{name:'Joy',status:'done',date:'12-11-2018'}]
  constructor() { }

  ngOnInit() {
  }

}
