import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout/layout.component';
import { OrderListComponent } from './order-list/order-list.component';
import { PassportComponent } from './passport/passport.component';
import { VisaComponent } from './visa/visa.component';
// import {OrderListComponent} from './';

const childRoutes: Routes = [
            {
                path:'user',
                component:LayoutComponent,
                
            },
            {
                path:'order',
                component:OrderListComponent
            },
            {
                path:'passport',
                component:PassportComponent
            },
            {
                path:'visa',
                component:VisaComponent
            },

            
   
];

export const routing = RouterModule.forChild(childRoutes);
