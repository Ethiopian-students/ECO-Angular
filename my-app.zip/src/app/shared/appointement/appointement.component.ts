import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointement',
  templateUrl: './appointement.component.html',
  styleUrls: ['./appointement.component.css']
})
export class AppointementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
