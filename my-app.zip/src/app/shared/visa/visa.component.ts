import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visa',
  templateUrl: './visa.component.html',
  styleUrls: ['./visa.component.css']
})
export class VisaComponent implements OnInit {
  visa
  constructor() { }

  ngOnInit() {
  }

  onSubmit()
  {}

}
