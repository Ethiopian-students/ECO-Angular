import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutComponent } from './layout/layout.component';
import { routing } from './user.route';
import { OrderListComponent } from './order-list/order-list.component';
import { AppointementComponent } from './appointement/appointement.component';
import { VisaComponent } from './visa/visa.component';
import { PassportComponent } from './passport/passport.component';

@NgModule({
  imports: [
    CommonModule,
    routing
  ],
  declarations: [LayoutComponent, OrderListComponent, AppointementComponent, VisaComponent, PassportComponent]
})
export class UserSystemModule { }
