import { Component, OnInit } from '@angular/core';
import { QuestionService } from './question.service';
import { QuestionBase } from './question-base';
import { extend } from 'webdriver-js-extender';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'Tour of Heroes';
  questions=[];
  constructor(private _questionService:QuestionService)
  {
   
  }

  ngOnInit() {
    this.questions = this._questionService.getQuestions();
    
    console.log(this.questions)
  }

  addComponenet()
  {
    this.questions.push(this._questionService.getQuestions());
  }
}
