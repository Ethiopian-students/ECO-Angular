import { Injectable } from '@angular/core';
import { QuestionBase } from './question-base';
import { FormControl, Validators, FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class QuestionControlService {

  constructor() { }

  toFormGroup(questions: QuestionBase<any>[] ) {
    let group: any = {};

    questions.forEach(question => {
      group[question.key] = question.required ? [question.value || '', Validators.required]
                                              : [question.value];
    });
    return group;
    // return new FormGroup(group);
  }
}
/**
 *  formRender()
   {
      this.facilityForm =this.fb.group({
        facilityArray:this.fb.array([this.fb.group({
                                      ftype :[''],
                                      count:['1']
                                    })]),
        hallsArray:this.fb.array([this.fb.group({hallName:[],
                                            price:[],
                                            timeFormat:[]})])
      })
   }
 */
