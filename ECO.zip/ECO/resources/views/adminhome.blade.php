 @extends('layouts.admin')

@section('content')
<p>This admin home</p>
@endsection