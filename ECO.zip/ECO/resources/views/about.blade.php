@extends('layouts.mylayout')
@section('content')

Ths is about page
@endsection