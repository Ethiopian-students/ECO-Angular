@extends('layouts.mylayout')
@section('content')
<p>Ths is contact page</p>
@endsection