<?php $__env->startSection('content'); ?>
<p>Ths is contact page</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mylayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/eco/resources/views/contact.blade.php ENDPATH**/ ?>