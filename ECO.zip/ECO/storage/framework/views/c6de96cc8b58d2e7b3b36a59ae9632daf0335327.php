<?php $__env->startSection('content'); ?>

Ths is about page
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mylayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/eco/resources/views/about.blade.php ENDPATH**/ ?>