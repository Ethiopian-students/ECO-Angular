<!DOCTYPE html>
<html>
<head>
    <title> Ethiopian Consulate Office</title>
</head>
<body>
<!-- page layout template. Content will be displayed and format definition.
<?php echo $__env->yieldContent; ?> - section will call and hold the content value 
    -->
    <div class="header">This is header</div>
    <?php echo $__env->yieldContent('content'); ?>
    <div class="footer">This is fotter</div>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/eco/resources/views/layouts/pageslayout.blade.php ENDPATH**/ ?>